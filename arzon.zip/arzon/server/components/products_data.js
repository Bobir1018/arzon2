import { Meteor } from 'meteor/meteor';

// Products data. Initiate on startup.
if (Products.find().count() === 0) {
console.log('Loading Products data.');
  let products = [
      {
        name: 'The Property',
        image: '/images/property.jpg',
        listingsCount: 0,
        productOffersCount: 0,
        productSoldCount: 0
      },
      {
        name: 'Transport',
        image: '/images/transport.jpg',
        listingsCount: 0,
        productOffersCount: 0,
        productSoldCount: 0
      },
      {
        name: 'Food Products',
        image: '/images/food.jpg',
        listingsCount: 0,
        productOffersCount: 0,
        productSoldCount: 0
      },
      {
        name: 'Electronics',
        image: '/images/elektroniks.jpg',
        listingsCount: 0,
        productOffersCount: 0,
        productSoldCount: 0
      },
      {
        name: 'Personal Things',
        image: '/images/personal.jpg',
        listingsCount: 0,
        productOffersCount: 0,
        productSoldCount: 0
      },
      {
        name: 'Services',
        image: '/images/servise.jpg',
        listingsCount: 0,
        productOffersCount: 0,
        productSoldCount: 0
      },
      {
        name: 'Animals',
        image: '/images/animals.jpg',
        listingsCount: 0,
        productOffersCount: 0,
        productSoldCount: 0
      },
      {
        name: 'Others',
        image: '/images/others.jpg',
        listingsCount: 0,
        productOffersCount: 0,
        productSoldCount: 0
      }
  ];
  products.forEach(function(product){
    Products.insert(product);
  });
}
